/**
 * Created by wbb on 16/5/26.
 */
/**
 * Created by wbb on 16/4/26.
 */
$(function() {
    var global = {
        hostId: $('.j-host-id').val()
    },statusMap = {
        0: '异常',
        1: '正常'
    };

    (function init(){

        setInterval(function(){
            refresh()
        },30000);

        refresh();

    })();

    (function bingEvents(){})();
    function refresh(){
        getBasicInfo(global.hostId);
    }

    function updateBasicInfo(data){
        $('.j-name').text(data.name);
        $('.j-os').text(data.os);
        $('.j-ip').text(data.ip);
        $('.j-os-version').text(data.osversion);
        $('.j-band').text(data.model);
        $('.j-type').text(data.type);
        $('.j-runtime').text(data.runtime);
        $('.j-status').text(statusMap[data.status]);
    }

    function getBasicInfo(hostId){
        $.ajax({
            url: '/netinfoAPI',
            data: {
                hostid: hostId
            },
            success: function(data){
                updateBasicInfo(data);
            }
        });
    }
});