#encoding:utf-8
from django.shortcuts import render,render_to_response,redirect
from django.template import RequestContext
from django.http import HttpResponse,JsonResponse
from epm import models,form,utils
from EPM.settings import UploadDir,SqlDir,hosinfo,hosserverinfo
import time,datetime,re,json,hashlib,copy
from django.db.models import Q

# Create your views here.

#检验登录
def loginpub(fun):
    def inner(request):
        if not request.session.get('user', None):
            return redirect('/login/')
        request.session['user'] = request.session.get('user')
        return fun(request)
    return inner

#检验权限
def adminpub(fun):
    def inner(request):
        if request.session.get('roll') == 1:
            return fun(request)
        return JsonResponse({})
    return inner
#首页主机一览数据分类问题计数
def HostsProblemList(request):
    '''
    处理首页主机一览异步请求
    :param request: 请求信息
    :return: {'host':[正常数,问题数],'net':[正常数,问题数],'db':[正常数,问题数],'mw':[正常数,问题数]}
    '''
    res={'host':[0,0],'net':[0,0],'db':[0,0],'mw':[0,0]}
    assetClasssDic = {1: 'host', 2: 'db', 3: 'mw', 4: 'net'}
    hostsdic = {}
    hosdb = models.hosDb()
    if hosdb.connstatus:
        hosts = models.assetInfo.objects.filter(hostid__isnull=False)
        for host in hosts:
            res[assetClasssDic[host.assetClassID]][0] += 1
            hostsdic[host.hostid] = assetClasssDic[host.assetClassID]
        for event in hosdb.CurrencyIter(SqlDir['HostsProblemList']):
            res_key=hostsdic.get(event[0])
            if res_key:
                res[res_key][0]-=1
                res[res_key][1] += 1
    return JsonResponse(res)
#首页告警一览数据问题计数
def HostsProblemCount(request):
    '''
    处理首页告警一览异步请求
    :param request: 请求信息
    :return: {'all': [致命,严重,警告,主要], 'host': [致命,严重,警告,主要], 'net': [致命,严重,警告,主要], 'db': [致命,严重,警告,主要], 'mw': [致命,严重,警告,主要]}
    '''
    hosdb=models.hosDb()
    res = {'all': [0,0,0,0], 'host': [0,0,0,0], 'net': [0,0,0,0], 'db': [0,0,0,0], 'mw': [0,0,0,0]}
    assetClasssDic={1:'host',2:'db',3:'mw',4:'net'}
    hostslist=[]
    hostsdic={}
    if hosdb.connstatus:
        hosts = models.assetInfo.objects.filter(hostid__isnull=False)
        for host in hosts:
            hostslist.append(host.hostid)
            hostsdic[host.hostid] = assetClasssDic[host.assetClassID]
        for event in hosdb.CurrencyIter(SqlDir['HostsProblemCount']):
            res_key=hostsdic.get(event[4])
            if res_key:
                res['all'][3-event[2]-2]+=1
                res[res_key][3-event[2]-2]+=1
    return JsonResponse(res)
# 文件上传
def upload(request):
    tempdic={}
    if request.method == "POST":
        uf = form.FileForm(request.POST,request.FILES)
        if uf.is_valid():
            #获取表单信息
            headImg = uf.cleaned_data.get('UploadFile')
            if headImg:
                filepath = '%s/%s_%s' % (UploadDir,int(time.mktime(time.localtime())), headImg.name,)
                with open(filepath, mode='wb') as file:
                    for i in headImg.chunks():
                        file.write(i)
                file.close()
                return JsonResponse({'filepath':'/%s' % (filepath)})
        return JsonResponse({'filepath':''})
    tempdic['uploadform'] = form.FileForm()
    return render_to_response('upload.html',tempdic)
#告警信息异步
def AlarmInfor(request):
    sql = SqlDir['AlarmInfor']
    starttime=request.POST.get('starttime', None)
    stoptime=request.POST.get('stoptime', None)
    level=request.POST.get('level', None)
    sql=utils.MakeSqlStr(sql,'`events`.`clock`',starttime,'>',IsTimeStr=True)
    sql=utils.MakeSqlStr(sql,'`events`.`clock`',stoptime,'<',IsTimeStr=True)
    sql=utils.MakeSqlStr(sql,'`triggers`.`priority`',level,'=')
    ip=request.POST.get('ip',None)
    hostname=request.POST.get('hostname',None)
    assetclass=request.POST.get('assetclass',None)
    hostids,hostsIdName=utils.Hostids(hostname=hostname, ip=ip, assetclass=assetclass)
    page = int(request.POST.get('page', 1))
    rows = int(request.POST.get('rows', 20))
    print page,rows
    AlarmInforList = []
    count = 0
    if hostids:
        if len(hostids)>1:
            sql = utils.MakeSqlStr(sql, '`hosts`.`hostid`',tuple(hostids), 'IN')
        else:
            sql = utils.MakeSqlStr(sql, '`hosts`.`hostid`', hostids[0], '=')
        SqlWithLimit=' '.join([sql ,'LIMIT 1000'])
        hosdb = models.hosDb()
        if hosdb.connstatus:
            levels={2:'信息',3:'警告',4:'严重',5:'致命'}
            status={1:'问题',0:'恢复'}
            inform={0:'否'}

            count=int(hosdb.CurrencyIter("SELECT COUNT(countall.eventid) FROM (%s) AS countall" % (sql)).next()[0])
            for event in hosdb.CurrencyAll(SqlWithLimit):
                isinform=inform.get(hosdb.CurrencyIter("SELECT COUNT(error) from alerts WHERE error=Null AND eventid=%s" % int(event[1])).next()[0],'是')
                event={'levent':levels[event[8]],'name':hostsIdName.get(event[2],['',''])[0],'ip':hostsIdName.get(event[2],['',''])[1],'info':event[5],'time':event[0],'type':status[event[7]],'inform':isinform}
                AlarmInforList.append(event)
            AlarmInforList = sorted(AlarmInforList,key=lambda event:event['time'],reverse=True)

    return JsonResponse({'total':count,'rows':AlarmInforList[(page-1)*rows:page*rows]})
#拓扑图！！！！！！！！！！！！！
def topology(request):
    topologyinfo=models.topology_info.objects.all()
    result={}
    for i in  topologyinfo:
        result[i.name] = {'coordinate': i.coordinate, 'status': 0}
        packet_loss=utils.ItemHistory(SqlDir['HostBase'],i.hostid,'丢包率')
        if packet_loss:
            if packet_loss[0][4][0][0]!=100:
                result[i.name]['status'] = 1
    return JsonResponse(result)

#主机情况-基本信息
def HostBase(request):
    hostid=request.GET.get('hostid',None)
    if hostid:
        hostTime=str(datetime.datetime.fromtimestamp(utils.ItemHistory(SqlDir['HostBase'],hostid,'服务器本地时间')[0][4][0][0]))
        runTime=utils.ItemHistory(SqlDir['HostBase'],hostid,'系统开机时间')[0][4][0][0]
        day,runTime=divmod(runTime,24*60*60)
        hour,runTime=divmod(runTime,60*60)
        minute,second=divmod(runTime,60)
        runTime='%s天%s小时%s分钟%s秒' % (day,hour,minute,second)
        host=models.assetInfo.objects.get(hostid=hostid)
        assetClasssDic = {1: '主机', 2: '数据库', 3: '中间件', 4: '网络'}
        assetClasssName=assetClasssDic[host.assetClassID]
        hosdb = models.hosDb()
        for event in hosdb.CurrencyIter(SqlDir['HostsProblemList']):
            if event[0] == int(hostid):
                hoststatus='异常'
                break
        else:
            hoststatus = '正常'
        result={'name':host.assetName,'ip':host.iPAddr,'class':assetClasssName,'os':host.factoryOS,'starttime':hostTime,'runtime':runTime ,'status':hoststatus}
        return JsonResponse(result)
    return JsonResponse({'name':'','ip':'','class':'','os':'','starttime':'','runtime':'','status':''})
#主机情况-CPU
def HostCPU(request):
    hostid=request.GET.get('hostid',None)
    starttime=utils.MakeStarttime()
    result=JsonResponse(utils.formatresult(utils.cpumem(hostid, starttime, 'CPU用户态使用时间比', '+', 'CPU系统态使用时间比')))
    result['Access-Control-Allow-Origin'] = '*'
    return result
    #return JsonResponse(utils.formatresult(utils.cpumem(hostid,starttime,'CPU用户态使用时间比','+','CPU系统态使用时间比')))
#主机情况-内存
def HostMEM(request):
    hostid=request.GET.get('hostid',None)
    starttime = utils.MakeStarttime()
    return JsonResponse(utils.formatresult(utils.cpumem(hostid,starttime,'空闲内存','/','总内存',usenew=True),symbol='(1-data)*100'))
#主机情况-虚拟内存
def HostVMMEM(request):
    hostid = request.GET.get('hostid', None)
    result={'new':0}
    if hostid:
        vmmemfree = utils.ItemHistory(SqlDir['HostBase'], hostid, '空闲虚拟内存')[0][4][0][0]
        vmmemtotal = utils.ItemHistory(SqlDir['HostBase'], hostid, '总虚拟内存')[0][4][0][0]
        result={'new':round((vmmemtotal-vmmemfree)/vmmemtotal,1)}
    return JsonResponse(result)
#主机情况-文件系统
def HostFilesystem(request):
    hostid=request.GET.get('hostid',None)
    result = {'data':[]}
    if hostid:
        FilesystemDatas = utils.ItemHistory(SqlDir['HostBase'], hostid, '文件系统空闲空间比：%')
        if FilesystemDatas:
            FilesystemThreshold=int(models.paramInfo.objects.get(paramName='FT').value)
            for FilesystemData in FilesystemDatas:
                usedP=round(100-FilesystemData[4][0][0],1)
                if usedP>FilesystemThreshold:
                    status='异常'
                else:
                    status='正常'
                result['data'].append({'name': re.findall(r'\[(.+)\]', FilesystemData[3])[0].split(',')[int(re.findall(r'\$(\d+)', FilesystemData[2])[0]) - 1],
                                       'value': round(usedP, 1), 'AlarmValue': FilesystemThreshold, 'status': status})

    return JsonResponse(result)
#用户管理表接口
def UserInfoApi(request):
    users=models.UserInfo.objects.all()
    rolls=models.RollInfo.objects.all()
    departs=models.paramInfo.objects.filter(paramName='BM')
    usersinfo=[]
    for user in users:
        if user.loginName !='admin':
            usersinfo.append({'id':user.userID,'loginname':user.loginName,'name':user.userName,
                          'tel':user.tel,'depart':user.depart.value,'rollname':user.rollID.rollName})
        #usersinfo.append([user.userID,user.loginName,user.userName,user.tel,user.depart.value,user.rollID.rollName])
    rollsinfo={}
    for roll in rolls:
        rollsinfo[roll.rollID]=roll.rollName
    departsinfo={}
    for depart in departs:
        departsinfo[depart.xh]=depart.value
    return JsonResponse({'users':usersinfo,'rolls':rollsinfo,'departs':departsinfo})
#用户删除接口
@adminpub
def UserDel(request):
    userids=request.POST.get('users','').split(',')
    models.UserInfo.objects.filter(userID__in=userids).delete()
    return JsonResponse({})
#用户添加接口
@adminpub
def UserAdd(request):
    loginName=request.POST.get('loginName',None)
    userName=request.POST.get('userName',None)
    password=request.POST.get('password',None)
    depart=request.POST.get('depart',None)
    tel=request.POST.get('tel',None)
    rollID=request.POST.get('rollID',None)
    userID=request.POST.get('id')
    if userID:
        if loginName and depart and rollID:
            rollID=models.RollInfo.objects.get(rollID=int(rollID.encode(encoding='utf-8')))
            depart=models.paramInfo.objects.get(xh=int(depart.encode(encoding='utf-8')))
            models.UserInfo.objects.filter(userID=userID).update(loginName=loginName,userName=userName,
                                           depart=depart,tel=tel,rollID=rollID,flag=1)
            return JsonResponse({'result': 1})
        else:
            return JsonResponse({'result': 0})
    if loginName and password and depart and rollID:
        if not models.UserInfo.objects.filter(loginName=loginName):
            hash = hashlib.sha256()
            hash.update(password)
            password=hash.hexdigest()
            rollID=models.RollInfo.objects.get(rollID=int(rollID.encode(encoding='utf-8')))
            depart=models.paramInfo.objects.get(xh=int(depart.encode(encoding='utf-8')))
            models.UserInfo.objects.create(loginName=loginName,userName=userName,password=password,
                                           depart=depart,tel=tel,rollID=rollID,flag=1)
            return JsonResponse({'result': 1})
        else:
            return JsonResponse({'result': -1})
    return JsonResponse({'result': 0})
#资源详情接口
def assetInfoAPI(request):
    assetID=request.GET.get('assetID',None)
    assetinfo={}
    if assetID:
        cabinetinfodic=utils.cabinetInfoDic()
        factoryinfodic=utils.factoryInfoDic()
        assetsonclassdic = utils.assetSonClasssDic()
        maintaininfodic = utils.maintainInfoDic()
        moniterStatusDic={1:'监控中',0:'未监控',3:'未知'}
        asset=utils.assetinfo(assetID=assetID)
        if len(asset)!=0:
            assetinfo = {'data':asset[0],'cabinetinfodic':cabinetinfodic,
                         'factoryinfodic':factoryinfodic,
                         'assetsonclassdic':assetsonclassdic,
                         'moniterStatusDic':moniterStatusDic,
                         'maintaininfodic': maintaininfodic}
    return JsonResponse(assetinfo)
#监控项接口
def itemsAPI(request):
    hostid = request.GET.get('hostid', None)
    page=int(request.GET.get('page', 1))
    rows=int(request.GET.get('rows',20))
    result=[]
    rowsdata=[]
    if hostid:
        result=utils.ItemsHistoryTriggers(hostid)
        rowsdata=result[(page-1)*rows:page*rows]
    return JsonResponse({'total':len(result),'rows':rowsdata})
#资源管理
def assetlistAPI(request):
    assetinfo = {'total':0,'rows':[]}
    iPAddr=request.POST.get('iPAddr')
    assetName=request.POST.get('assetName')
    assetClassID=request.POST.get('assetClassID')
    moniter=request.POST.get('moniter')
    for i in [iPAddr,assetClassID,assetName,moniter]:
        print type(i)
    cabinetinfodic = utils.cabinetInfoDic()
    factoryinfodic = utils.factoryInfoDic()
    assetsonclassdic = utils.assetSonClasssDic()
    maintaininfodic = utils.maintainInfoDic()
    templatesdic=utils.TemplatesDic()
    moniterStatusDic={1:'监控中',0:'未监控',3:'未知'}
    asset=utils.assetinfo(iPAddr=iPAddr,assetName=assetName,assetClassID=assetClassID,moniter=moniter)
    if len(asset)!=0:
        page = int(request.POST.get('page', 1))
        rows = int(request.POST.get('rows', 20))
        assetinfo = {'total':len(asset),'rows':asset[(page-1)*rows:page*rows],
                     'cabinetinfodic': cabinetinfodic,
                     'factoryinfodic': factoryinfodic,
                     'assetsonclassdic': assetsonclassdic,
                     'moniterStatusDic': moniterStatusDic,
                     'maintaininfodic':maintaininfodic,
                     'templatesdic':templatesdic}
    return JsonResponse(assetinfo)

#新增资源
def addasset(request):
    assetName=request.POST.get('assetName')
    assetClassID=request.POST.get('assetClassID')
    assetClassID2=request.POST.get('assetClassID2')
    factoryID=request.POST.get('factoryID')
    iPAddr=request.POST.get('iPAddr')
    iPAddr2=request.POST.get('iPAddr2')
    iPManage=request.POST.get('iPManage')
    factoryOS=request.POST.get('factoryOS')
    osVersion=request.POST.get('osVersion')
    factoryType=request.POST.get('factoryType')
    factorySerial=request.POST.get('factorySerial')
    buyDate=request.POST.get('buyDate')
    expireDate=request.POST.get('expireDate')
    roomID=request.POST.get('roomID')
    cabinetID=request.POST.get('cabinetID')
    rackNumber=request.POST.get('rackNumber')
    useStatus=request.POST.get('useStatus')
    usedDept=request.POST.get('usedDept')
    usedFor=request.POST.get('usedFor')
    maintainStaus=request.POST.get('maintainStaus')
    maintainID=request.POST.get('maintainID')
    pic1=request.POST.get('pic1')
    pic2=request.POST.get('pic2')
    assetDetail=request.POST.get('assetDetail')
    asseMemo=request.POST.get('asseMemo')
    macAddr = request.POST.get('macAddr')
    # assetClassID=models.assetClass.objects.get(assetClassID=assetClassID)
    # assetClassID2=models.assetSonClass.objects.get(assetSonClassID=assetClassID2)
    # factoryID=models.factoryInfo.objects.get(factoryID=factoryID)
    # roomID=models.roomInfo.objects.get(roomID=roomID)
    # cabinetID=models.cabinetInfo.objects.get(cabinetID=cabinetID)
    # if maintainID:maintainID=models.maintainInfo.objects.get(maintainID=maintainID)
    try:
        models.assetInfo.objects.create(assetName=assetName,factoryOS=factoryOS,
                                        osVersion=osVersion,iPAddr=iPAddr,iPAddr2=iPAddr2,
                                        iPManage=iPManage,macAddr=macAddr,
                                        assetClassID=assetClassID,assetClassID2=assetClassID2,
                                        factoryID=factoryID,factoryType=factoryType,
                                        factorySerial=factorySerial,roomID=roomID,
                                        cabinetID=cabinetID,rackNumber=rackNumber,buyDate=buyDate,
                                        expireDate=expireDate,maintainStaus=maintainStaus,
                                        useStatus=useStatus,usedDept=usedDept,usedFor=usedFor,
                                        assetDetail=assetDetail,asseMemo=asseMemo,flag=1,
                                        pic1=pic1,pic2=pic2,assetReger=request.session.get('user'),
                                        maintainID=maintainID)
        maintainName=request.POST.get('maintainName')
        if maintainID and maintainName:
            maintaincontacts=request.POST.get('maintaincontacts')
            maintaintel=request.POST.get('maintaintel')
            maintainemail=request.POST.get('maintainemail')
            models.maintainInfo.objects.filter(maintainID=maintainID).update(maintainName=maintainName,
                                                                             contacts=maintaincontacts,
                                                                             tel=maintaintel,
                                                                             email=maintainemail)

        factoryName=request.POST.get('factoryName')
        if factoryID and factoryName:
            factorycontacts=request.POST.get('factorycontacts')
            factorytel=request.POST.get('factorytel')
            factoryemail=request.POST.get('factoryemail')
            models.factoryInfo.objects.filter(factoryID=factoryID).update(factoryName=factoryName,
                                                                          contacts=factorycontacts,
                                                                          tel=factorytel,
                                                                          email=factoryemail)
    except:
        return JsonResponse({'result':0})
    return JsonResponse({'result':1})

#oracle基本信息
def oracleBaseinfo(request):
    hostid=request.GET.get('hostid')
    result={}
    if hostid:
        runtime=utils.ItemHistory(SqlDir['HostBase'], hostid, '数据库运行时间')[0][4][0][0]
        starttime=utils.ItemHistory(SqlDir['HostBase'], hostid, '数据库启动时间')[0][4][0][0]
        dbversion=utils.ItemHistory(SqlDir['HostBase'], hostid, '数据库版本')[0][4][0][0]
        nowuser=utils.ItemHistory(SqlDir['HostBase'], hostid, '连接用户数')[0][4][0][0]
        nowpro = utils.ItemHistory(SqlDir['HostBase'], hostid, '当前进程数')[0][4][0][0]
        maxpro = utils.ItemHistory(SqlDir['HostBase'], hostid, '最大进程数')[0][4][0][0]
        status = utils.ItemHistory(SqlDir['HostBase'], hostid, 'oracle是否存活%')[0][4][0][0]
        os=models.assetInfo.objects.get(hostid=hostid).factoryOS
        result={'runtime':'{}分钟'.format(runtime),'starttime':starttime,'dbversion':dbversion,
                'nowuser':nowuser,'nowpro':nowpro,'maxpro':maxpro,'status':status,'os':os}
    return JsonResponse(result)
#oracle表空间
def oracleTableSpace(request):
    hostid=request.GET.get('hostid')
    result={'total':0,'rows':[]}
    if hostid:
        tmpspacedic={}
        for tmpspace in utils.ItemHistory(SqlDir['HostBase'], hostid, '总表空间 $%'):
            key=re.findall(r'\[(.+)\]', tmpspace[3])[0].split(',')[int(re.findall(r'\$(\d+)',tmpspace[2])[0]) - 1]
            tmpspacedic[key]={'total':tmpspace[4][0][0]}
        for tmpspace in utils.ItemHistory(SqlDir['HostBase'], hostid, '空闲表空间 $%'):
            key=re.findall(r'\[(.+)\]', tmpspace[3])[0].split(',')[int(re.findall(r'\$(\d+)',tmpspace[2])[0]) - 1]
            tmpspacedic[key]['free']=tmpspace[4][0][0]
        for tmpspace in utils.ItemHistory(SqlDir['HostBase'], hostid, '表空间空闲比 $%'):
            key=re.findall(r'\[(.+)\]', tmpspace[3])[0].split(',')[int(re.findall(r'\$(\d+)',tmpspace[2])[0]) - 1]
            tmpspacedic[key]['freeP']=tmpspace[4][0][0]
        result['total']=len(tmpspacedic)
        for key,value in tmpspacedic.items():
            result['rows'].append({'name':key,'total':value['total'],
                                  'free':value['free'],'usedP':100-value['freeP']})
    return JsonResponse(result)
#oracle会话数
def oracleSession(request):
    hostid=request.GET.get('hostid')
    result={}
    if hostid:
        syssession=utils.ItemHistory(SqlDir['HostBase'], hostid, '系统会话数')[0][4][0][0]
        runsession=utils.ItemHistory(SqlDir['HostBase'], hostid, '正在执行的连接会话数')[0][4][0][0]
        waitsession=utils.ItemHistory(SqlDir['HostBase'], hostid, '正在等待的连接会话数')[0][4][0][0]
        allsession=utils.ItemHistory(SqlDir['HostBase'], hostid, '总的连接会话数')[0][4][0][0]
        maxsession = utils.ItemHistory(SqlDir['HostBase'], hostid, '最大会话数')[0][4][0][0]
        result={'syssession':syssession,'runsession':runsession,'waitsession':waitsession,
                'allsession':allsession,'maxsession':maxsession,}
    return JsonResponse(result)
#oracle命中率
def oracleHitratio(request):
    hostid=request.GET.get('hostid')
    result={'alltime':[],'all_shared_pool':[],'all_db_cache':[]}
    starttime=utils.MakeStarttime()
    shared_pool_hitratios = utils.ItemHistory(SqlDir['HostBase'], hostid, '共享池命中率', starttime)
    db_cache_hitratios = utils.ItemHistory(SqlDir['HostBase'], hostid, '缓冲区命中率', starttime)
    for shared_pool_hitratio in shared_pool_hitratios[0][4]:
        result['alltime'].append(shared_pool_hitratio[1])
        result['all_shared_pool'].append(shared_pool_hitratio[0])
    for db_cache_hitratio in db_cache_hitratios[0][4]:
        result['all_db_cache'].append(db_cache_hitratio[0])

    return JsonResponse(result)
#登录页
def login(request):
    utils.check_ED()
    if request.method == 'POST':
        user=request.POST.get('user',None)
        password=request.POST.get('password',None)
        # print user,password
        if user and password:
            hash = hashlib.sha256()
            hash.update(password)
            password=hash.hexdigest()
            authtologin=models.UserInfo.objects.filter(userName=user,password=password)
            if authtologin.count() == 1:
                request.session['user'] = user
                request.session['roll'] = authtologin[0].rollID_id
                return JsonResponse({'result':True})
            else:
                return JsonResponse({})
        return JsonResponse({})
    if not request.session.get('user', None):
        return render_to_response('login.html')
    else:
        return redirect('/')

#密码修改
def changepasswd(request):
    user=request.session.get('user')
    password=request.POST.get('password')
    newpassword = request.POST.get('newpassword')
    print user,password,newpassword
    if password and newpassword:
        hash = hashlib.sha256()
        hash.update(password)
        password=hash.hexdigest()
        authtochangepasswd = models.UserInfo.objects.filter(userName=user, password=password)
        if authtochangepasswd:
            hash = hashlib.sha256()
            hash.update(newpassword)
            newpassword = hash.hexdigest()
            models.UserInfo.objects.filter(userName=user).update(password=newpassword)
            result='修改成功！'
        else:
            result='原密码错误，修改失败！'

    return JsonResponse({'result':result})

#登出
def logout(request):
    try:
        del request.session['user']
    except:
        return redirect('/')
    else:return redirect('/')

#巡检记录API
def inspectInfoAPI(request):
    result={'total':0,'rows':[]}
    post = request.POST
    start=post.get('start')
    stop=post.get('stop')
    InspectID=post.get('InspectID')
    Inspecter=post.get('Inspecter')
    inspectInfos=models.inspectInfo.objects.filter()
    if start:
        start=datetime.datetime.strptime(start,'%Y-%m-%d')
        inspectInfos=inspectInfos.filter(InspectDate__gte=start)
    if stop:
        stop=datetime.datetime.strptime(stop,'%Y-%m-%d')
        inspectInfos=inspectInfos.filter(InspectDate__lte=stop)
    if InspectID:
        inspectInfos=inspectInfos.filter(InspectID=InspectID)
    if Inspecter:
        inspectInfos=inspectInfos.filter(Inspecter=Inspecter)
    result['total']=inspectInfos.count()
    page=int(post.get('page',1))
    rows=int(post.get('rows',20))
    inspectInfos=inspectInfos[rows*(page-1):rows*page]
    for inspectInfo in inspectInfos:
        result['rows'].append({'InspectID':inspectInfo.InspectID,'InspectName':inspectInfo.InspectName,
                              'InspectDate':inspectInfo.InspectDate,'Inspecter':inspectInfo.Inspecter,
                              'InspectTel':inspectInfo.InspectTel,'confirmer':inspectInfo.confirmer,
                              'confirmerTel':inspectInfo.confirmerTel,'partChanged':inspectInfo.partChanged,
                              'suggestDoc':inspectInfo.suggestDoc,'confirmpic':inspectInfo.confirmpic,
                              'InspectProb':inspectInfo.InspectProb,'solution':inspectInfo.solution,
                              'suggest':inspectInfo.suggest})
    return JsonResponse(result)
#增加巡检记录API
def AddInspectInfoAPI(request):
    post=request.POST
    InspectName=post.get('InspectName')
    InspectDate=post.get('InspectDate')
    Inspecter=post.get('Inspecter')
    InspectTel=post.get('InspectTel')
    confirmer=post.get('confirmer')
    confirmerTel=post.get('confirmerTel')
    partChanged=int(post.get('partChanged',0))
    suggestDoc=post.get('suggestDoc')
    confirmpic=post.get('confirmpic')
    InspectProb=post.get('InspectProb')
    solution=post.get('solution')
    suggest=post.get('suggest')
    inspectDetail=post.get('inspectDetail')
    if InspectDate:
        InspectDate=datetime.datetime.strptime(InspectDate,'%Y-%m-%d')
    models.inspectInfo.objects.create(InspectName=InspectName,InspectDate=InspectDate,Inspecter=Inspecter,
                                      InspectTel=InspectTel,confirmer=confirmer,confirmerTel=confirmerTel,
                                      partChanged=partChanged,suggestDoc=suggestDoc,confirmpic=confirmpic,
                                      InspectProb=InspectProb,solution=solution,suggest=suggest)
    if inspectDetail:
        InspectInfoObject=models.inspectInfo.objects.get(InspectName=InspectName,InspectDate=InspectDate)
        for detail in json.loads(inspectDetail)['rows']:
            models.inspectDetail.objects.create(InspectClass=detail['InspectClass'],
                                                InspectResult=detail['InspectResult'],
                                                InspectProb=detail['InspectProb'],
                                                solution=detail['solution'],
                                                pic=detail['pic'],
                                                finishedPic=detail['finishedPic'],
                                                InspectID=InspectInfoObject)


    return JsonResponse({})
#配件更换API
def partInfoAPI(request):
    partTypeDIC={}
    for parttypeobject in models.paramInfo.objects.filter(paramName='PJLX'):
        partTypeDIC.setdefault(parttypeobject.xh,parttypeobject.value)
    cabinetinfodic = utils.cabinetInfoDic()
    result={'total':0,'rows':[],'partTypeDIC':partTypeDIC,'cabinetinfodic':cabinetinfodic}
    post = request.POST
    start=post.get('start')
    stop=post.get('stop')
    partID=post.get('partID')
    partType=post.get('partType')
    partInfos=models.partInfo.objects.filter()
    if start:
        start=datetime.datetime.strptime(start,'%Y-%m-%d')
        partInfos=partInfos.filter(changeDate__gte=start)
    if stop:
        stop=datetime.datetime.strptime(stop,'%Y-%m-%d')
        partInfos=partInfos.filter(changeDate__lte=stop)
    if partID:
        partInfos=partInfos.filter(partID=partID)
    if partType:
        partInfos=partInfos.filter(partType__value=partType)
    result['total']=partInfos.count()
    page=int(post.get('page',1))
    rows=int(post.get('rows',20))
    partInfos=partInfos[rows*(page-1):rows*page]
    for partinfo in partInfos:
        result['rows'].append({'partID':partinfo.partID,'partName':partinfo.partName,
                               'partType':partinfo.partType.xh,'beforeSerial':partinfo.beforeSerial,
                               'partSerial':partinfo.partSerial,'beforePic':partinfo.beforePic,
                               'finishedPic':partinfo.finishedPic,'whychange':partinfo.whychange,
                               'changeDate':partinfo.changeDate,'changer':partinfo.changer,
                               'tel':partinfo.tel,'memo':partinfo.memo,'rackNumber':partinfo.rackNumber,
                               'roomID':partinfo.roomID.roomID,'cabinetID':partinfo.cabinetID.cabinetID})
    return JsonResponse(result)
#增加配件更换API
def AddPartInfoAPI(request):
    post = request.POST
    partName=post.get('partName')
    partType=models.paramInfo.objects.get(xh=int(post.get('partType',5)))
    beforeSerial=post.get('beforeSerial')
    partSerial=post.get('partSerial')
    beforePic=post.get('beforePic')
    finishedPic=post.get('finishedPic')
    whychange=post.get('whychange')
    changeDate=post.get('changeDate')
    if changeDate:
        changeDate=datetime.datetime.strptime(changeDate,'%Y-%m-%d')
    changer=post.get('changer')
    tel=post.get('tel')
    memo=post.get('memo')
    roomID=models.roomInfo.objects.get(roomID=int(post.get('roomID',1)))
    cabinetID=models.cabinetInfo.objects.get(cabinetID=int(post.get('cabinetID',1)))
    rackNumber=post.get('rackNumber')
    models.partInfo.objects.create(partName=partName,beforeSerial=beforeSerial,
                                      roomID=roomID,cabinetID=cabinetID,
                                      rackNumber=rackNumber,partType=partType,
                                      partSerial=partSerial,
                                      beforePic=beforePic,finishedPic=finishedPic,whychange=whychange,
                                      changeDate=changeDate,changer=changer,tel=tel,memo=memo)

    return JsonResponse({})

def AddToHos(request):
    post=request.POST
    assetid=int(post.get('assetid'))
    templates=post.get('templates')
    assetdata=models.assetInfo.objects.filter(assetID=assetid)
    assetdata.update(MonitoringTemplate=templates)
    templates=[{'templateid':i} for i in templates.split(',')]
    hosapi = utils.hosAPI(hosinfo['url'])
    token=hosapi.login(hosinfo['user'], hosinfo['passwd']).get('result')
    if token:
        hostid=None
        if assetdata[0].hostid:
            hostid = hosapi.hostupdate(assetdata[0].hostid,templates,token).get('result')
        elif assetdata[0].iPAddr:
            hostid = hosapi.hostcreate(assetdata[0].iPAddr,templates,token).get('result')
        if hostid:
            assetdata.update(hostid=int(hostid['hostids'][0]))
            return JsonResponse({'result':1})
    return JsonResponse({'result':0})

def MonitorResources(request):
    MonitorHosts=models.assetInfo.objects.filter(hostid__isnull=False)
    assetclasssdic=utils.assetClasssDic()['name']
    result={'name':[],'count':[]}
    for key in sorted(assetclasssdic.keys()):
        result['name'].append(assetclasssdic[key])
        result['count'].append(MonitorHosts.filter(assetClassID=key).count())
    return JsonResponse(result)

def HostProblemTOP(request):
    result = {'name': [], 'count': []}
    hosdb=models.hosDb()
    hostsdic={}
    hosts = models.assetInfo.objects.filter(hostid__isnull=False)
    for host in hosts:
        hostsdic[host.hostid]={'name':host.assetName,'count':0}
    for event in hosdb.CurrencyIter(SqlDir['HostsProblemCount']):
        hostsdic[event[4]]['count']+=1
    for i in sorted(hostsdic.values(),key=lambda i:i['count'],reverse=True)[0:5]:
        result['name'].append(i['name'])
        result['count'].append(i['count'])
    return JsonResponse(result)

def HostCPUTOP(request):
    result = {'name': [], 'cpuusedP': []}
    hosdb=models.hosDb()
    hostsdic={}
    hosts = models.assetInfo.objects.filter(hostid__isnull=False)
    for host in hosts:
        hostsdic[host.hostid]={'name':host.assetName,'cpuusedP':0}
        usrp=utils.ItemHistory(SqlDir['HostBase'], host.hostid, 'CPU用户态使用时间比')
        sysp=utils.ItemHistory(SqlDir['HostBase'], host.hostid, 'CPU系统态使用时间比')
        if usrp and sysp:
            hostsdic[host.hostid]['cpuusedP']=usrp[0][4][0][0]+sysp[0][4][0][0]

    for i in sorted(hostsdic.values(),key=lambda i:i['cpuusedP'],reverse=True)[0:5]:
        result['name'].append(i['name'])
        result['cpuusedP'].append(i['cpuusedP'])
    return JsonResponse(result)

def TuxedoInfo(request):
    hostid=request.GET.get('hostid')
    result={}
    if hostid:
        version = utils.ItemHistory(SqlDir['HostBase'], hostid, 'tuxedo版本')[0][4][0][0]
        bit = utils.ItemHistory(SqlDir['HostBase'], hostid, 'tuxedo版本位数')[0][4][0][0]
        server = utils.ItemHistory(SqlDir['HostBase'], hostid, '最大容许应用数')[0][4][0][0]
        services = utils.ItemHistory(SqlDir['HostBase'], hostid, '最大容许服务数')[0][4][0][0]
        access = utils.ItemHistory(SqlDir['HostBase'], hostid, '最大容许访问数')[0][4][0][0]
        result = {'version': version, 'bit': bit, 'server': server, 'services': services, 'access': access,
                  'serviceinfo': [], 'queueinfo': []}
        tmpdic={}
        for tmpserviceinfo in utils.ItemHistory(SqlDir['HostBase'], hostid, 'tuxedo_service处理请求数-%'):
            tmpdic[re.findall(r'\[(.+?)\]',tmpserviceinfo[3])[0]]={'Done':tmpserviceinfo[4][0][0]}
        for tmpserviceinfo in utils.ItemHistory(SqlDir['HostBase'], hostid, 'tuxedo_service状态-%'):
            if tmpserviceinfo[4][0][0]==1:
                status='可用'
            else:
                status = '不可用'
            tmpdic[re.findall(r'\[(.+?)\]',tmpserviceinfo[3])[0]]['Status']=status
        for tmpkey,tmpvalue in tmpdic.items():
            ServiceName,RoutineName,GrpName,ID=tmpkey.split('|')
            result['serviceinfo'].append({'Done': tmpvalue['Done'], 'Status': tmpvalue['Status'],
                                          'ServiceName': ServiceName, 'RoutineName': RoutineName,
                                          'GrpName': GrpName, 'ID': ID})
        tmpdic = {}
        for tmpserviceinfo in utils.ItemHistory(SqlDir['HostBase'], hostid, 'tuxedo队列请求数-%'):
            tmpdic[re.findall(r'\[(.+?)\]',tmpserviceinfo[3])[0]]={'Queued':tmpserviceinfo[4][0][0]}
        for tmpserviceinfo in utils.ItemHistory(SqlDir['HostBase'], hostid, 'tuxedo队列连接服务数-%'):
            tmpdic[re.findall(r'\[(.+?)\]',tmpserviceinfo[3])[0]]['WkQueued']=tmpserviceinfo[4][0][0]
        for tmpserviceinfo in utils.ItemHistory(SqlDir['HostBase'], hostid, 'tuxedo队列平均长度-%'):
            tmpdic[re.findall(r'\[(.+?)\]',tmpserviceinfo[3])[0]]['AveLen']=tmpserviceinfo[4][0][0]
        for tmpkey,tmpvalue in tmpdic.items():
            ProgName,QueueName,Machine=tmpkey.split('|')
            result['queueinfo'].append({'Queued':tmpvalue['Queued'],'WkQueued':tmpvalue['WkQueued'],
                                          'AveLen':tmpvalue['AveLen'],'ProgName':ProgName,
                                          'QueueName':QueueName, 'Machine':Machine})
    return JsonResponse(result)

def dealAPI(request):
    post = request.POST
    start=post.get('start')
    stop=post.get('stop')
    page=int(post.get('page',1))
    rows=int(post.get('rows',20))
    if start:
        result=models.TuxedoTransaction.objects.filter(crsj__gte=time.mktime(time.strptime(start,'%Y-%m-%d %H:%M')))
    else:
        start=int(time.mktime(datetime.datetime.timetuple(datetime.datetime.now()-datetime.timedelta(hours=10))))
        result=models.TuxedoTransaction.objects.filter(crsj__gte=start)
    if stop:
        result=result.filter(crsj__lte=datetime.datetime.strptime(stop,'%Y-%m-%d %H:%M'))
    count=result.count()
    rowslist=[]
    for deal in result.order_by('-cssj')[(page-1)*rows:page*rows]:
        rowslist.append({'jylx':deal.jylx,'jyjg':deal.jyjg,'jyhs':deal.jyhs,'yybh':deal.yybh,'ip':deal.ip})
    return JsonResponse({'total':count,'rows':rowslist})

def JbossTabAPI(request):
    hostid=request.GET.get('hostid')
    result={}
    if hostid:
        jbossversion = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss版本')
        jbossjavaversion = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jbossjava版本')
        jbossgc_OC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jbossOld代的容量')
        jbossgc_OU = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jbossOld代目前已使用空间')
        jbossname = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jbossjava中间件名称')
        jbossjavapath = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jbossjava路径')
        jbossgc_S1C = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss年轻代中第二个survivor（幸存区）的容量')
        jbossgc_S1U = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss年轻代中第二个survivor（幸存区）目前已使用空间')
        jbossgc_S0U = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss年轻代中第一个survivor（幸存区）目前已使用空间')
        jbossgc_S0C = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss年轻代中第一个survivor（幸存区）的容量')
        jbossgc_EU = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss年轻代中Eden（伊甸园）目前已使用空间')
        jbossgc_EC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss年轻代中Eden（伊甸园）的容量')
        jbossjavastatus = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss可用性')
        jbossgc_YGC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss从应用程序启动到采样时年轻代中gc次数')
        jbossgc_YGCT = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss从应用程序启动到采样时年轻代中gc所用时间')
        jbossgc_FGCT = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss从应用程序启动到采样时old代(全gc)gc所用时间')
        jbossgc_FGC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss从应用程序启动到采样时old代(全gc)gc次数')
        jbossgc_GCT=utils.ItemHistory(SqlDir['HostBase'], hostid, 'jboss从应用程序启动到采样时gc用的总时间')
        result={'jbossversion':jbossversion,'jbossjavaversion':jbossjavaversion,'jbossname':jbossname,
                'jbossgc_OC':jbossgc_OC,'jbossgc_OU':jbossgc_OU,'jbossjavapath':jbossjavapath,
                'jbossgc_S1C':jbossgc_S1C,'jbossgc_S1U':jbossgc_S1U,'jbossgc_S0U':jbossgc_S0U,
                'jbossgc_S0C':jbossgc_S0C,'jbossgc_EU':jbossgc_EU,'jbossgc_EC':jbossgc_EC,
                'jbossjavastatus':jbossjavastatus,'jbossgc_YGC':jbossgc_YGC,
                'jbossgc_YGCT':jbossgc_YGCT,'jbossgc_FGCT ':jbossgc_FGCT,'jbossgc_FGC':jbossgc_FGC,
                'jbossgc_GCT':jbossgc_GCT}
        for key,value in result.items():
            if value:
                result[key]=value[0][4][0][0]
            else:
                result[key]=''
        urls = utils.ItemHistory(SqlDir['HostBase'], hostid, 'URL_%')
        tmpurlsdic={}
        for url in urls:
            urlname=re.findall(r'url_\[jboss(.+?)\]',url[3])
            if urlname:
                tmpurlsdic[urlname[0]]=url[4][0][0]
        urls = utils.ItemHistory(SqlDir['HostBase'], hostid, 'URLPATH_%')
        tmpurlsdic2 = {}
        for url in urls:
            urlname = re.findall(r'urlpath_\[jboss(.+?)\]', url[3])
            if urlname:
                tmpurlsdic2[urlname[0]] = url[4][0][0]
        urlslist=[]
        for key in set(tmpurlsdic.keys())&set(tmpurlsdic2.keys()):
            urlslist.append({'name':key,'url':tmpurlsdic2[key],'status':tmpurlsdic[key]})
        result['urlslist']=urlslist
    return JsonResponse(result)

def WeblogicTabAPI(request):
    hostid=request.GET.get('hostid')
    result={}
    if hostid:
        weblogicversion = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic版本')
        weblogicjavaversion = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogicjava版本')
        weblogicgc_OC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogicOld代的容量')
        weblogicgc_OU = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogicOld代目前已使用空间')
        weblogicname = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogicjava中间件名称')
        weblogicjavapath = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogicjava路径')
        weblogicgc_S1C = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic年轻代中第二个survivor（幸存区）的容量')
        weblogicgc_S1U = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic年轻代中第二个survivor（幸存区）目前已使用空间')
        weblogicgc_S0U = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic年轻代中第一个survivor（幸存区）目前已使用空间')
        weblogicgc_S0C = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic年轻代中第一个survivor（幸存区）的容量')
        weblogicgc_EU = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic年轻代中Eden（伊甸园）目前已使用空间')
        weblogicgc_EC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic年轻代中Eden（伊甸园）的容量')
        weblogicjavastatus = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic可用性')
        weblogicgc_YGC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic从应用程序启动到采样时年轻代中gc次数')
        weblogicgc_YGCT = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic从应用程序启动到采样时年轻代中gc所用时间')
        weblogicgc_FGCT = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic从应用程序启动到采样时old代(全gc)gc所用时间')
        weblogicgc_FGC = utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic从应用程序启动到采样时old代(全gc)gc次数')
        weblogicgc_GCT=utils.ItemHistory(SqlDir['HostBase'], hostid, 'weblogic从应用程序启动到采样时gc用的总时间')
        result={'weblogicversion':weblogicversion,'weblogicjavaversion':weblogicjavaversion,'weblogicname':weblogicname,
                'weblogicgc_OC':weblogicgc_OC,'weblogicgc_OU':weblogicgc_OU,'weblogicjavapath':weblogicjavapath,
                'weblogicgc_S1C':weblogicgc_S1C,'weblogicgc_S1U':weblogicgc_S1U,'weblogicgc_S0U':weblogicgc_S0U,
                'weblogicgc_S0C':weblogicgc_S0C,'weblogicgc_EU':weblogicgc_EU,'weblogicgc_EC':weblogicgc_EC,
                'weblogicjavastatus':weblogicjavastatus,'weblogicgc_YGC':weblogicgc_YGC,
                'weblogicgc_YGCT':weblogicgc_YGCT,'weblogicgc_FGCT ':weblogicgc_FGCT,'weblogicgc_FGC':weblogicgc_FGC,
                'weblogicgc_GCT':weblogicgc_GCT}
        for key,value in result.items():
            if value:
                result[key]=value[0][4][0][0]
            else:
                result[key]=''
        urls = utils.ItemHistory(SqlDir['HostBase'], hostid, 'URL_%')
        tmpurlsdic={}
        for url in urls:
            urlname=re.findall(r'url_\[weblogic(.+?)\]',url[3])
            if urlname:
                tmpurlsdic[urlname[0]]=url[4][0][0]
        urls = utils.ItemHistory(SqlDir['HostBase'], hostid, 'URLPATH_%')
        tmpurlsdic2 = {}
        for url in urls:
            urlname = re.findall(r'urlpath_\[weblogic(.+?)\]', url[3])
            if urlname:
                tmpurlsdic2[urlname[0]] = url[4][0][0]
        urlslist=[]
        for key in set(tmpurlsdic.keys())&set(tmpurlsdic2.keys()):
            urlslist.append({'name':key,'url':tmpurlsdic2[key],'status':tmpurlsdic[key]})
        result['urlslist']=urlslist
    return JsonResponse(result)

def netinfoAPI(request):
    return JsonResponse({'name':'资源名','os':'系统','ip':'ip','osversion':'系统版本',
                         'model':'型号','type':'类型','runtime':'运行时间','status':1})

def GetRemindCount(request):
    return JsonResponse({'num':models.remind_info.objects.filter(readflag=0).count()})

def RemindInfo(request):
    post = request.POST
    start=post.get('start')
    nowdate=datetime.datetime.now()
    stop=post.get('stop','{}-{}-{}'.format(nowdate.year,nowdate.month,nowdate.day))
    page=int(post.get('page',1))
    rows=int(post.get('rows',20))
    if start:
        print start
        result=models.remind_info.objects.filter(date__gte=datetime.datetime.strptime(start,'%Y-%m-%d'),date__lte=datetime.datetime.strptime(stop,'%Y-%m-%d')).order_by('-id')
    else:
        result = models.remind_info.objects.filter(date__lte=datetime.datetime.strptime(stop,'%Y-%m-%d')).order_by('-id')[0:100]
    count=result.count()
    rowslist=[]
    for i in result[(page-1)*rows:page*rows]:
        rowslist.append({'id':i.id,'title':i.title,'message':i.message,
                         'date':i.date,'readflag':i.readflag,'remark':i.remark})
    models.remind_info.objects.filter(readflag=0).update(readflag=1)

    return JsonResponse({'total':count,'rows':rowslist})

def DbSummary(request):
    dblist=[]
    hosts=models.assetInfo.objects.filter(MonitoringTemplate__isnull=False)
    templates=utils.TemplatesDic()
    for key,value in templates.items():
        if value=='oracle':
            tempid=key
    for host in hosts:
        if str(tempid) in host.MonitoringTemplate:
            dblist.append(host)
    dbname=[]
    tablespace=[]
    for db in dblist:

        alltableP=utils.ItemHistory(SqlDir['HostBase'], db.hostid, '总表空间使用率')
        if alltableP:
            dbname.append(db.assetName)
            tablespace.append(alltableP[0][4][0][0])
    return JsonResponse({'dbname':dbname,'tablespace':tablespace})


def MWTransaction(request):
    start = int(time.mktime(datetime.datetime.timetuple(datetime.datetime.now() - datetime.timedelta(hours=1))))
    result = models.TuxedoTransaction.objects.filter(crsj__gte=start)
    date=[]
    data=[]
    for i in result:
        date.append(i.jylx)
        data.append(i.jyhs)
    return JsonResponse({'date':date,'data':data})
    # return JsonResponse({'date':['a','b','c'],'data':[1,2,3]})
#首页
@loginpub
def index(request):
    return render_to_response('index.html',context={'title':'首页'})
#告警管理
#@loginpub
def alarmMgnt(request):
    return render_to_response('alarmMgnt.html',context={'title':'告警管理'})
#用户管理
#@loginpub
def sysMgntuser(request):
    return render_to_response('sysMgnt/user.html',context={'title':'用户管理'})
#主机情况
#@loginpub
def resourceMgntHost(request):
    assetID=request.GET.get('assetID')
    if assetID:
        return render_to_response('host.html',
                                  context={'title': '主机管理',
                                           'hostId':models.assetInfo.objects.get(assetID=assetID).hostid,
                                           'assetID':assetID,
                                           'resourceMgntHost':True,
                                           }
                                  )
#网络管理
#@loginpub
def resourceMgntNet(request):
    assetID = request.GET.get('assetID')
    return render_to_response('net.html',
                              context={'title': '网络管理',
                                       'hostId': models.assetInfo.objects.get(assetID=assetID).hostid,
                                       'assetID': assetID,
                                       'resourceMgntNet':True,
                                       }
                              )
#oracle管理
#@loginpub
def resourceMgntOracle(request):
    assetID = request.GET.get('assetID')
    return render_to_response('oracle.html',
                              context={'title': '网络管理',
                                       'hostId': models.assetInfo.objects.get(assetID=assetID).hostid,
                                       'assetID': assetID,
                                       'resourceMgntOracle':True,
                                       }
                              )
#监控项详情
#@loginpub
def resourceMgntMonitorItem(request):
    assetID = request.GET.get('assetID')
    return render_to_response('monitorItem.html',
                              context={'title': '网络管理',
                                       'hostId': models.assetInfo.objects.get(assetID=assetID).hostid,
                                       'assetID': assetID,
                                       'resourceMgntMonitorItem':True,
                                       }
                              )

def resourceMgnt(request):
    return render_to_response('resourceMgnt.html',context={'title':'资源管理'})

def checkMgntcheck(request):
    return render_to_response('checkMgnt.html',content_type={'title':'巡检记录'})

def senddata(request):
    if request.method == 'POST':
        hostname=request.POST.get('hostname',None)
        key=request.POST.get('key',None)
        value=request.POST.get('value',None)
        if hostname and key and value:
            zabbixsendfile=hosserverinfo['hossendfile']
            zabbixserverip=hosserverinfo['hosserverip']
            zabbixserverport=hosserverinfo['hosserverport']
            sbyzabbixs=utils.sendbyhossend(zabbixsendfile,zabbixserverip,zabbixserverport)
            sbyzabbixsresult=sbyzabbixs.sendbyzabbixsend(hostname,key,value)
            return HttpResponse(sbyzabbixsresult)
        else:
            return HttpResponse(2)
    else:
        return HttpResponse(1)

@loginpub
def network(request):
    return render_to_response('network.html', content_type={'title': '网络拓扑'})

@loginpub
def message(request):
    return render_to_response('message.html', content_type={'title': '消息提醒'})

@loginpub
def QAAtrade(request):
    return render_to_response('QAA/trade.html', content_type={'title': '交易分析'})

@loginpub
def QAATOP(request):
    return render_to_response('QAA/Top.html', content_type={'title': 'TOP分析'})