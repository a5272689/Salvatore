#encoding:utf-8
from __future__ import unicode_literals

from django.db import models
from EPM.settings import hosDB
import MySQLdb,functools

# Create your models here.
#参数表
class paramInfo(models.Model):
    xh=models.AutoField(primary_key=True)
    paramName=models.CharField(max_length=20)
    value=models.CharField(max_length=50,null=True,blank=True)
    parent=models.CharField(max_length=50,null=True,blank=True)
    memo=models.CharField(max_length=50,null=True,blank=True)

    class Meta:
        verbose_name = '参数表'
        verbose_name_plural = '参数表'

    def __unicode__(self):
        return self.paramName+self.value
#资产分类表
class assetClass(models.Model):
    assetClassID=models.AutoField(primary_key=True)
    assetClassName=models.CharField(max_length=50)
    assetClassMemo=models.CharField(max_length=200,null=True,blank=True)
    parentClassID=models.BigIntegerField(null=True,blank=True)
    flag=models.IntegerField()

    class Meta:
        verbose_name = '资产分类表'
        verbose_name_plural = '资产分类表'

    def __unicode__(self):
        return self.assetClassName

# 资产二级分类表
class assetSonClass(models.Model):
    assetSonClassID = models.AutoField(primary_key=True)
    assetSonClassName = models.CharField(max_length=50)
    assetSonClassMemo = models.CharField(max_length=200, null=True,blank=True)
    parentClassID = models.ForeignKey('assetClass')
    flag = models.IntegerField()

    class Meta:
        verbose_name = '资产二级分类表'
        verbose_name_plural = '资产二级分类表'

    def __unicode__(self):
        return self.assetSonClassName
# app一级分类对照表
class appClass(models.Model):
    appClassID=models.AutoField(primary_key=True)
    parentClassID=models.ForeignKey('assetClass')
    appName=models.CharField(max_length=50)


    class Meta:
        verbose_name = 'APP分类表'
        verbose_name_plural = 'APP分类表'


    def __unicode__(self):
        return self.appName
# 设备厂商信息表
class factoryInfo(models.Model):
    factoryID = models.AutoField(primary_key=True)
    factoryName = models.CharField(max_length=50)
    contacts = models.CharField(max_length=20, null=True,blank=True)
    tel = models.CharField(max_length=20, null=True,blank=True)
    email = models.CharField(max_length=40, null=True,blank=True)
    memo = models.CharField(max_length=200, null=True,blank=True)

    class Meta:
        verbose_name = '设备厂商信息表'
        verbose_name_plural = '设备厂商信息表'


    def __unicode__(self):
        return self.factoryName
# 机房信息表
class roomInfo(models.Model):
    roomID = models.AutoField(primary_key=True)
    roomName=models.CharField(max_length=50)
    roomPlace=models.ForeignKey('paramInfo')
    roomAddr=models.CharField(max_length=100,null=True,blank=True)
    roomPic1=models.CharField(max_length=80,null=True,blank=True)
    roomPic2=models.CharField(max_length=80,null=True,blank=True)
    roomPic3=models.CharField(max_length=80,null=True,blank=True)
    roomPic4=models.CharField(max_length=80,null=True,blank=True)
    memo=models.CharField(max_length=200,null=True,blank=True)
    flag=models.IntegerField()

    class Meta:
        verbose_name = '机房信息表'
        verbose_name_plural = '机房信息表'

    def __unicode__(self):
        return self.roomName
#机柜信息表
class cabinetInfo(models.Model):
    cabinetID=models.AutoField(primary_key=True)
    cabinetName=models.CharField(max_length=50)
    cabinetType=models.CharField(max_length=50,null=True,blank=True)
    factoryID=models.ForeignKey('factoryInfo')
    cabinetSerial=models.CharField(max_length=50,null=True,blank=True)
    cabinetPlace=models.CharField(max_length=50,null=True,blank=True)
    roomID=models.ForeignKey('roomInfo')
    cabinetSpec=models.CharField(max_length=20,null=True,blank=True)
    cabinetPic1=models.CharField(max_length=80,null=True,blank=True)
    cabinetPic2=models.CharField(max_length=80,null=True,blank=True)
    cabinetPic3=models.CharField(max_length=80,null=True,blank=True)
    cabinetPic4=models.CharField(max_length=80,null=True,blank=True)
    cabinetMemo=models.CharField(max_length=200,null=True,blank=True)
    flag=models.IntegerField()


    class Meta:
        verbose_name = '机柜信息表'
        verbose_name_plural = '机柜信息表'

    def __unicode__(self):
        return self.cabinetName
# 维保单位信息表
class maintainInfo(models.Model):
    maintainID = models.AutoField(primary_key=True)
    maintainName = models.CharField(max_length=50)
    contacts = models.CharField(max_length=20, null=True,blank=True)
    tel = models.CharField(max_length=20, null=True,blank=True)
    email = models.CharField(max_length=40, null=True,blank=True)
    memo = models.CharField(max_length=200, null=True,blank=True)

    class Meta:
        verbose_name = '维保单位信息表'
        verbose_name_plural = '维保单位信息表'


    def __unicode__(self):
        return self.maintainName
# 资产登记表
class assetInfo(models.Model):
    assetID = models.AutoField(primary_key=True)
    assetName = models.CharField(max_length=40)
    assetClassID=models.IntegerField()
    assetClassID2=models.IntegerField()
    factoryID=models.IntegerField()
    iPAddr=models.CharField(max_length=20)
    iPAddr2=models.CharField(max_length=20,null=True)
    iPManage=models.CharField(max_length=20,null=True)
    factoryOS=models.CharField(max_length=40)
    osVersion=models.CharField(max_length=20)
    factoryType=models.CharField(max_length=40,null=True)
    factorySerial=models.CharField(max_length=40,null=True)
    buyDate=models.DateField(null=True)
    expireDate=models.DateField(null=True)
    roomID=models.IntegerField()
    cabinetID=models.IntegerField()
    rackNumber=models.IntegerField(null=True)
    moniterStatus=models.IntegerField(null=True)
    hostid=models.BigIntegerField(null=True)
    useStatus=models.IntegerField(null=True)
    usedDept=models.IntegerField(null=True)
    usedFor=models.CharField(max_length=20,null=True)
    assetReger=models.CharField(max_length=20,null=True)
    assetRegtime=models.DateField(auto_now=True)
    maintainStaus=models.IntegerField(null=True)
    maintainID=models.IntegerField(null=True)
    pic1=models.CharField(max_length=80,null=True)
    pic2=models.CharField(max_length=80,null=True)
    assetDetail=models.CharField(max_length=100,null=True)
    asseMemo=models.CharField(max_length=200,null=True)
    flag=models.IntegerField(null=True)
    macAddr = models.CharField(max_length=200, null=True, blank=True)
    MonitoringTemplate = models.CharField(max_length=500, null=True, blank=True)
#巡检信息总表
class inspectInfo(models.Model):
    InspectID=models.AutoField(primary_key=True)
    InspectName=models.CharField(max_length=50)
    InspectDate=models.DateField(null=True)
    Inspecter=models.CharField(max_length=20,null=True)
    InspectTel=models.CharField(max_length=20,null=True)
    inspectResult=models.IntegerField(null=True)
    InspectProb=models.CharField(max_length=200,null=True)
    solution=models.CharField(max_length=200,null=True)
    suggest=models.CharField(max_length=200,null=True)
    suggestDoc=models.CharField(max_length=80,null=True)
    partChanged=models.IntegerField(null=True)
    satisfaction=models.IntegerField(null=True)
    confirmer=models.CharField(max_length=20,null=True)
    confirmerTel=models.CharField(max_length=20,null=True)
    confirmpic=models.CharField(max_length=80,null=True)
    memo=models.CharField(max_length=200,null=True)
#巡检信息子表
class inspectDetail(models.Model):
    xh=models.AutoField(primary_key=True)
    InspectID=models.ForeignKey('inspectInfo')
    InspectClass=models.CharField(max_length=50)
    InspectResult=models.IntegerField()
    InspectProb=models.CharField(max_length=50,null=True)
    pic=models.CharField(max_length=50,null=True)
    solution=models.CharField(max_length=80,null=True)
    finishedPic=models.CharField(max_length=80,null=True)
    suggest=models.CharField(max_length=200,null=True)
#配件更换记录表
class partInfo(models.Model):
    partID=models.AutoField(primary_key=True)
    #InspectID=models.ForeignKey('inspectInfo',null=True)
    partName=models.CharField(max_length=50)
    partType=models.ForeignKey('paramInfo')
    beforeSerial=models.CharField(max_length=50,null=True)
    partSerial=models.CharField(max_length=50,null=True)
    beforePic=models.CharField(max_length=80,null=True)
    finishedPic=models.CharField(max_length=80,null=True)
    whychange=models.CharField(max_length=100,null=True)
    changeDate=models.DateField(null=True)
    changer=models.CharField(max_length=20,null=True)
    tel=models.CharField(max_length=20,null=True)
    memo=models.CharField(max_length=200,null=True)
    rackNumber=models.CharField(max_length=20,null=True)
    roomID=models.ForeignKey('roomInfo')
    cabinetID=models.ForeignKey('cabinetInfo')
#用户表
class UserInfo(models.Model):
    userID=models.AutoField(primary_key=True)
    loginName=models.CharField(max_length=20,unique=True)
    userName=models.CharField(max_length=20,null=True)
    password=models.CharField(max_length=70)
    depart=models.ForeignKey('paramInfo')
    tel=models.CharField(max_length=20,null=True)
    rollID=models.ForeignKey('RollInfo')
    pic=models.CharField(max_length=80,null=True)
    flag=models.IntegerField()
#角色表
class RollInfo(models.Model):
    rollID=models.AutoField(primary_key=True)
    rollName=models.CharField(max_length=20)
    flag=models.IntegerField()

    class Meta:
        verbose_name = '角色表'
        verbose_name_plural = '角色表'

    def __unicode__(self):
        return self.rollName
#模块表
class ModuleInfo(models.Model):
    moduleID=models.AutoField(primary_key=True)
    moduleName=models.CharField(max_length=20)
    flag=models.IntegerField()
#角色模块对照表
class RollModule(models.Model):
    rollID=models.ForeignKey('RollInfo')
    moduleID=models.ForeignKey('ModuleInfo')
    flag=models.IntegerField()
#权限表
class RightInfo(models.Model):
    rightID=models.ForeignKey('RollInfo')
    rightInfo=models.CharField(max_length=50)
    flag=models.IntegerField()

    class Meta:
        verbose_name = '权限表'
        verbose_name_plural = '权限表'

    def __unicode__(self):
        return self.rightInfo
#模块权限对照表dgEmcVmax100k.png
class ModuleRight(models.Model):
    moduleID=models.ForeignKey('ModuleInfo')
    rightID=models.ForeignKey('rightInfo')
    flag=models.IntegerField()

#
class TuxedoTransaction(models.Model):
    id=models.AutoField(primary_key=True)
    jylx=models.CharField(max_length=4)
    jyjg=models.IntegerField()
    crsj=models.IntegerField()
    cssj=models.IntegerField()
    jyhs=models.FloatField()
    ip=models.CharField(max_length=16)
    yybh=models.CharField(max_length=10)
#
class topology_info(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=30)
    coordinate=models.CharField(max_length=30)
    hostid=models.IntegerField()
    class Meta:
        verbose_name = '拓扑图信息表'
        verbose_name_plural = '拓扑图信息表'


    def __unicode__(self):
        return self.name

class remind_info(models.Model):
    id=models.AutoField(primary_key=True)
    assetID=models.ForeignKey('assetInfo')
    title=models.CharField(max_length=20)
    message=models.CharField(max_length=500)
    date=models.DateField(auto_now_add=True)
    readflag=models.IntegerField()
    remark=models.CharField(max_length=200,null=True)
    type=models.IntegerField()
#Hos系统数据库
class hosDb(object):
    '''
    hos数据库相关操作
    '''
    def __init__(self):
        '''
        连接数据库，正常连接字段connstatus为真并配置指针否则为假
        '''
        try:
            self.conn=MySQLdb.connect(host=hosDB['host'],port=hosDB['port'],user=hosDB['user'],passwd=hosDB['passwd'],charset=hosDB['charset'],db=hosDB['db'])
        except:
            self.connstatus=False
        else:
            self.connstatus=True
            self.__cur=self.conn.cursor()

    def CurrencyAll(self,sql):
        '''
        执行sql语句,返回结果
        :param sql: sql语句
        :return: 把fetchall结果转换成list的结果
        '''
        self.__cur.execute(sql)
        return self.__cur.fetchall()
    def CurrencyIter(self,sql):
        '''
        执行sql语句,返回结果
        :param sql: sql语句
        :return: 迭代把fetchone结果转换成list的结果
        '''
        self.__cur.execute(sql)
        result = self.__cur.fetchone()
        while result:
            yield list(result)
            result = self.__cur.fetchone()

    def __del__(self):
        self.__cur.close()
        self.conn.close()

