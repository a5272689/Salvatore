# Register your models here.
from django.contrib import admin

from epm import models

admin.site.register(models.paramInfo)
admin.site.register(models.RightInfo)
admin.site.register(models.RollInfo)
admin.site.register(models.cabinetInfo)
admin.site.register(models.roomInfo)
admin.site.register(models.assetClass)
admin.site.register(models.assetSonClass)
admin.site.register(models.factoryInfo)
admin.site.register(models.maintainInfo)
admin.site.register(models.appClass)
admin.site.register(models.topology_info)