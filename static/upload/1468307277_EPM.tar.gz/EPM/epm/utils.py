#-*- coding:utf-8 -*-
#author:hjd
import time,datetime,urllib2,json,urllib,subprocess
from epm import models
from django.db.models import Q
from EPM.settings import SqlDir
import sys,re
reload(sys)
sys.setdefaultencoding('utf8')

def assetClasssDic():
    '''
    整理assetClass表的一级分类成字典
    :return: name分类名 memo分类描诉，这里是分类的英文名
    '''
    assetClasssdic={'name':{},'memo':{}}
    assetClasss=models.assetClass.objects.filter(parentClassID__isnull=True)
    for assetClass in assetClasss:
        assetClasssdic['name'][assetClass.assetClassID]=assetClass.assetClassName
        assetClasssdic['memo'][assetClass.assetClassID] = assetClass.assetClassMemo
    return assetClasssdic

def assetClasssDic2():
    '''
    整理assetClass表的二级分类成字典
    :return: name分类名 memo分类描诉，这里是分类的英文名
    '''
    appclasssdic={'name':{},'classname':{}}
    appclasss=models.appClass.objects.all()
    for appclass in appclasss:
        appclasssdic['name'][appclass.appClassID]=appclass.appName
        appclasssdic['classname'][appclass.appName]=appclass.parentClassID.assetClassName
    return appclasssdic

def assetSonClasssDic():
    '''
    整理assetClass表的二级分类成字典
    :return: name分类名 'sonclass'子分类字典
    '''
    assetClasssdic={}
    for key,value in assetClasssDic()['name'].items():
        assetClasssdic[key]={'name':value,'sonclass':{}}
    assetSonClasss=models.assetSonClass.objects.filter()
    for assetSonClass in assetSonClasss:
        assetClasssdic[assetSonClass.parentClassID.assetClassID]['sonclass'][assetSonClass.assetSonClassID]=assetSonClass.assetSonClassName
    return assetClasssdic

def factoryInfoDic():
    '''
    整理factoryInfo表的二级分类成字典
    :return: name分类名
    '''
    factoryInfodic={}
    factoryInfos=models.factoryInfo.objects.filter()
    for factoryinfo in factoryInfos:
        factoryInfodic[factoryinfo.factoryID]={'name':factoryinfo.factoryName,
                                               'contacts':factoryinfo.contacts,
                                               'tel':factoryinfo.tel,
                                               'mail':factoryinfo.email}
    return factoryInfodic

def maintainInfoDic():
    '''
    整理maintainInfo表的二级分类成字典
    :return: name分类名
    '''
    maintainInfodic={}
    maintainInfos=models.maintainInfo.objects.filter()
    for maintaininfo in maintainInfos:
        maintainInfodic[maintaininfo.maintainID]={'name':maintaininfo.maintainName,
                                               'contacts':maintaininfo.contacts,
                                               'tel':maintaininfo.tel,
                                               'mail':maintaininfo.email}
    return maintainInfodic

def cabinetInfoDic():
    '''
    整理cabinetInfo表的二级分类成字典
    :return: name分类名
    '''
    roominfodic={}
    roominfos=models.roomInfo.objects.filter()
    for roominfo in roominfos:
        roominfodic[roominfo.roomID]={'name':roominfo.roomName,'cabinet':{}}
    for cabinetinfo in models.cabinetInfo.objects.filter():
        roominfodic[cabinetinfo.roomID.roomID]['cabinet'][cabinetinfo.cabinetID]=cabinetinfo.cabinetName
    return roominfodic

def MakeSqlStr(oldstr,fieldName,val,condition='=',IsTimeStr=False):
    if val:
        if IsTimeStr:
            newstr = ' '.join([oldstr, 'AND', '(', fieldName, condition, str(int(time.mktime(time.strptime(val,'%Y-%m-%d %H:%M')))), ')'])
        else:
            newstr=' '.join([oldstr,'AND','(',fieldName,condition,str(val),')'])
    else:
        newstr=oldstr
    return newstr
def MakeSqlLimit(oldstr,page,rows):
    if rows:
        if page:
            newstr='%s LIMIT %s,%s' % (oldstr,(int(page)-1)*int(rows),rows)
        else:
            newstr='%s LIMIT %s' % (oldstr,rows)
        return newstr
    else:
        return oldstr

def TemplatesDic():
    hosdb = models.hosDb()
    result={}
    for template in hosdb.CurrencyIter(SqlDir['selftemplates']):
        result[int(template[0])]=template[1]
    return result

def ItemHistory(sql,hostid,name,starttime=None):
    hosdb = models.hosDb()
    hosdb2 = models.hosDb()
    if hosdb:
        result=[]
        #print sql % (hostid,name)
        items=hosdb.CurrencyIter(sql % (hostid,name))
        for item in items:
            HistoryTableDic={0: 'history', 1: 'history_str', 2: 'history_log', 3: 'history_uint', 4: 'history_text'}
            if starttime:
                historys=hosdb2.CurrencyAll("SELECT `value`,FROM_UNIXTIME(clock) FROM %s WHERE itemid=%s AND clock>%s" % (HistoryTableDic[item[1]],item[0],starttime))
            else:
                historys = hosdb2.CurrencyAll("SELECT `value` FROM %s WHERE itemid=%s ORDER BY clock DESC LIMIT 1"% (HistoryTableDic[item[1]],item[0]))
                #print "SELECT `value` FROM %s WHERE itemid=%s ORDER BY clock DESC LIMIT 1"% (HistoryTableDic[item[1]],item[0])
            if historys:
                item.append(historys)
                result.append(item)
            else:
                return None
        return result
    return None

def makeitemname(name,key):
    keys=re.findall(r'\$(\d+?)',name)
    if keys:
        name=re.subn(r'\$\d+?',r'%s',name)[0]
        values = re.findall(r'\[(.+?)\]',key)[0].split(',')
        needvalues=[]
        for key in keys:
            needvalues.append(values[int(key)-1])

        name = name % tuple(needvalues)
    return name

def ItemsHistoryTriggers(hostid):
    #import json
    HistoryTableDic = {0: 'history', 1: 'history_str', 2: 'history_log', 3: 'history_uint', 4: 'history_text'}
    hosdb=models.hosDb()
    itemids=[]
    items=[]
    assetclasssdic2 = assetClasssDic2()['classname']
    triggers={}
    triggerstatusdic={0:'正常',1:'告警'}
    for trigger in hosdb.CurrencyAll(SqlDir['itemstriggersAPI'].format(hostid)):
        triggers['{}is'.format(trigger[0])]='有'
        triggers['{}val'.format(trigger[0])] = triggerstatusdic[trigger[1]]
    for item in hosdb.CurrencyAll(SqlDir['itemsAPI'].format(hostid)):
        itemdic={'delay':item[4],'name':makeitemname(item[2],item[3]),'assetclass':assetclasssdic2[item[5]],
                 'trigger':triggers.get('{}is'.format(item[0]),'无'),
                 'triggerstatus':triggers.get('{}val'.format(item[0]),'未知'),}
        itemids.append(item[0])
        hosdb2 = models.hosDb()
        history = hosdb2.CurrencyAll("SELECT `value` FROM %s WHERE itemid=%s ORDER BY clock DESC LIMIT 1" % (HistoryTableDic[item[1]], item[0]))
        if history:
            itemdic['nowvalue']=history[0][0]
        else:
            itemdic['nowvalue'] = ''
        items.append(itemdic)
    return items

def MakeStarttime(starttime=None):
    if starttime:
        return time.mktime(time.strptime(starttime,'%Y/%m/%d %H:%M:%S'))
    else:
        return time.mktime((datetime.datetime.now() - datetime.timedelta(hours=12)).timetuple())
def Hostids(ip=None,hostname=None,assetclass=None):
    hosts = models.assetInfo.objects.filter(hostid__isnull=False)
    if ip:
        hosts=hosts.filter(iPAddr__contains=ip)
    if hostname:
        hosts=hosts.filter(assetName__icontains=hostname)
    if assetclass:
        hosts=hosts.filter(assetClassID=assetclass)
    hostslist=[]
    hostsIdName={}
    for host in hosts:
        hostslist.append(int(host.hostid))
        hostsIdName[int(host.hostid)]=[host.assetName,host.iPAddr]
    return (hostslist,hostsIdName)
def cpumem(hostid,starttime,keyword1,symbol,keyword2,usenew=False):
    if hostid:
        Add=lambda x,y: float(x) + float(y)
        Reduce=lambda x,y:float(x) - float(y)
        Multiply=lambda x,y:float(x) * float(y)
        Divide=lambda x,y:float(x) / float(y)
        symbols={'+':Add,'-':Reduce,'*':Multiply,'/':Divide}
        keyword1s = ItemHistory(SqlDir['HostBase'], hostid, keyword1, starttime)
        keyword2s = ItemHistory(SqlDir['HostBase'], hostid, keyword2, starttime)
        if keyword1s and keyword2s:
            new = symbols[symbol](keyword1s[0][4][len(keyword1s[0][4])-1][0],keyword2s[0][4][len(keyword2s[0][4])-1][0])
            result = {'new': new, 'AllTime': [], 'AllData': []}
            if len(keyword1s[0][4]) <= len(keyword2s[0][4]):
                for num, data in enumerate(keyword1s[0][4]):
                    result['AllTime'].append(str(data[1]))
                    result['AllData'].append(symbols[symbol](data[0],keyword2s[0][4][num][0]))
            elif usenew:
                keyword2new=keyword2s[0][4][len(keyword2s[0][4])-1][0]
                for num, data in enumerate(keyword1s[0][4]):
                    result['AllTime'].append(str(data[1]))
                    result['AllData'].append(symbols[symbol](data[0],keyword2new))
            else:
                for num, data in enumerate(keyword2s[0][4]):
                    result['AllTime'].append(str(data[1]))
                    result['AllData'].append(symbols[symbol](keyword1s[0][4][num][0],data[0]))
        else:
            result = {'new': 0, 'AllTime': [], 'AllData': []}
        return result
    return {'new': 0, 'AllTime': [], 'AllData': []}
def formatresult(result,symbol="data"):
    if result['AllData']:
        data=result['new']
        result['new']=round(eval(symbol),1)
        AllData=[]
        for data in result['AllData']:
            AllData.append(round(eval(symbol),2))
        result['AllData']=AllData
    return result

def assetinfo(assetID=None,iPAddr=None,assetName=None,assetClassID=None,moniter=None):
    if assetID:
        assets = models.assetInfo.objects.filter(assetID=assetID)
    else:
        assets = models.assetInfo.objects.filter()
        if iPAddr:
            assets=assets.filter(iPAddr__contains = iPAddr)
        if assetName:
            assets = assets.filter(assetName__icontains = assetName)
        if assetClassID:
            assets=assets.filter(assetClassID=assetClassID)
        if moniter=='yes':
            assets=assets.filter(hostid__isnull=False)
        elif moniter=='no':
            assets=assets.filter(hostid__isnull=True)
    assetsinfos=[]
    for asset in assets:
        assetinfos = {'assetID': asset.assetID, 'assetName': asset.assetName,
                     'asseMemo': asset.asseMemo, 'iPAddr': asset.iPAddr, 'iPAddr2': asset.iPAddr2,
                     'iPManage': asset.iPManage, 'factoryOS': asset.factoryOS, 'osVersion': asset.osVersion,
                     'factoryType': asset.factoryType, 'factorySerial': asset.factorySerial,
                     'buyDate': asset.buyDate, 'expireDate': asset.expireDate, 'roomID': asset.roomID,
                     'cabinetID': asset.cabinetID, 'rackNumber': asset.rackNumber,
                     'useStatus': asset.useStatus, 'usedDept': asset.usedDept, 'usedFor': asset.usedFor,
                     'assetReger': asset.assetReger, 'assetRegtime': asset.assetRegtime,'hostid':asset.hostid,
                     'maintainStaus': asset.maintainStaus, 'maintainID': asset.maintainID,
                     'pic1': asset.pic1, 'pic2': asset.pic2, 'assetDetail': asset.assetDetail,
                     'assetClassID': asset.assetClassID,
                     'assetClassID2': asset.assetClassID2,
                     'moniterStatus': asset.moniterStatus,
                     'factoryID': asset.factoryID,
                     }
        for key, value in assetinfos.items():
            if value == None:
                assetinfos[key] = ''
        assetsinfos.append(assetinfos)
    return assetsinfos


class hosAPI(object):
    def __init__(self,url):
        self.url=url
        self.__header_dict = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',"Content-Type": "application/json"}

    def send(self,textmod):
        textmod = json.dumps(textmod).encode(encoding='utf-8')
        req = urllib2.Request(url=self.url, data=textmod, headers=self.__header_dict)
        res = urllib2.urlopen(req)
        res = res.read()
        return json.loads(res.decode(encoding='utf-8'))

    def login(self,user,passwd):
        textmod = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "user": user,
                "password": passwd
            },
            "id": 1,
            "auth": None
        }
        return self.send(textmod)
    def hostcreate(self,ip,templates,token):
        textmod = {
            "jsonrpc": "2.0",
            "method": "host.create",
            "params": {
                "host": ip,
                "interfaces": [
                    {
                        "type": 1,
                        "main": 1,
                        "useip": 1,
                        "ip": ip,
                        "dns": "",
                        "port": "10049"
                    }
                ],
                "groups": [
                    {
                        "groupid": "5"
                    }
                ],
                "templates": templates,
            },
            "auth": token,
            "id": 1
        }
        return self.send(textmod)

    def hostupdate(self,hostid,templates,token):
        textmod ={
                "jsonrpc": "2.0",
                "method": "host.update",
                "params": {
                    "hostid": hostid,
                    "templates": templates
                },
                "auth": token,
                "id": 1
            }
        return self.send(textmod)


class sendbyhossend(object):
    def __init__(self, zabbixsendfile, zabbixserverip, zabbixserverport):
        self.zabbixsendfile = zabbixsendfile
        self.zabbixserverip = zabbixserverip
        self.zabbixserverport = zabbixserverport

    def sendbyzabbixsend(self, hostname, key, value):
        action = "%s -z %s -p %s -s '%s' -k '%s' -o '%s' -vv" % (
        self.zabbixsendfile, self.zabbixserverip, self.zabbixserverport, hostname, key, value)
        sendresult = subprocess.call(action, shell=True)
        if sendresult == 0:
            return 0
        elif sendresult == 2:
            return 4
        else:
            return 3

def check_ED():
    allwithED=models.assetInfo.objects.filter(expireDate__isnull=False)
    factoryinfodic = factoryInfoDic()
    for i in allwithED:
        differ=(i.expireDate - datetime.datetime.now().date()).days
        remind=models.remind_info.objects.filter(assetID__assetID=i.assetID)
        if differ<=30 and not remind:
            models.remind_info.objects.create(assetID=i,title='出保提醒',
                                              message='设备(IP:{})将在{}天后出保，出保日期{}'.format(i.iPAddr,differ,i.expireDate),
                                              readflag=0,type=1)

