/**
 * Created by wbb on 16/5/26.
 */
/**
 * Created by wbb on 16/4/26.
 */
$(function() {
    var global = {};

    (function init(){
        global.tableService = $('.service-table').bootstrapTable({
            striped:true,
            columns: [{
                title: '应用服务名',
                field: 'id',
                align: 'center',
                valign: 'middle'
            }, {
                title: '应用名',
                field: 'id',
                align: 'center',
                valign: 'middle'
            }, {
                title: '组名',
                align: 'center'
            }, {
                field: 'name',
                title: 'ID',
                align: 'center'
            }, {
                field: 'price',
                title: '处理请求数',
                align: 'center'
            }, {
                field: 'price',
                title: '当前状态',
                align: 'center'
            }],
            data:[{},{},{},{},{}]
        });

        global.tableQueue = $('.queue-table').bootstrapTable({
            striped:true,
            columns: [{
                title: '应用名',
                field: 'id',
                align: 'center',
                valign: 'middle'
            }, {
                title: '队列名',
                field: 'id',
                align: 'center',
                valign: 'middle'
            }, {
                title: '逻辑机器名',
                align: 'center'
            }, {
                field: 'name',
                title: '连接服务数',
                align: 'center'
            }, {
                field: 'price',
                title: '队列请求数',
                align: 'center'
            }, {
                field: 'price',
                title: '队列平均长度',
                align: 'center'
            }],
            data:[{},{},{},{},{}]
        });
    })();

    (function bingEvents(){})();
});